const fs=require("fs")  
const readStream=fs.createReadStream("./test.txt") // creating readStream from writing file
const writeStream=fs.createWriteStream("./output.txt") //creating writeStream with new output file
// readStream.on('data',(chunk)=>{ // reading file data and converting it into chunks
//      console.log(chunk) //printing chunk by chunk
//     console.log(chunk.toString())
//    writeStream.write(chunk);// writing data to write stream chunk by chunk
// })


// readStream.on('end',()=>{ //looking for end of stream
//     console.log("Reached at the end of file")
//     writeStream.end() // ending writing chunks as no more chunks available
// })

readStream.pipe(writeStream); // creating pipe between readStream and writeStream for better streaming

writeStream.on("finish",()=>{ 
    console.log("End of stream.")
})


