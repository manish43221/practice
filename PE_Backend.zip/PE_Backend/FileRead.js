const fs=require("fs")
FilePath="./test.txt"
const res=fs.readFileSync(FilePath,"utf-8")
console.log(res)

//Reading file async
fs.readFile(FilePath,(err,data)=>{
    if(err) throw err
    console.log(data)
})
console.log("Hi")

