// //Call http module
// const http=require("http")
// //create http server
// const Port=3000;
// const server=http.createServer((req,res)=>{
//     res.end("Hello World")
// })
// server.listen(Port,()=>{
//     console.log("Server is listening....")
// })




// const http=require("http")

// const Port=4000;
// const server=http.createServer((req,res)=>{
//     if(req.url==="/"&&req.method==="GET"){
//         res.end("You are at Home Page")
//     }
//     else if(req.url==="/About"&&req.method==="GET")
//     {
//        res.end("Code is about request and response")
//     }
//     else if(req.url==="/Contact"&&req.method==="GET"){
//         res.end("Contact")
//     }
//     else{
//         res.statusCode=404;
//         res.end("Page Not Found")
//     }
// })
// server.listen(Port,()=>{
//     console.log("Server is listening....")
// })


// const http=require("http")


// const Port=3000;
// const server=http.createServer((req,res)=>{
//     switch(req.url){
//         case "/":
//             res.end("you are at home page")
//             console.log(req.headers)
//             break;
        

//         case "/About":
//             res.end("you are at about page")
//             break;

//         case "/Contact":
//             res.end("this is contact page")
//             break;

//         default:
//             res.statusCode=404;
//             res.end("Page not found")
//             break;
//     }
// })
// server.listen(Port,()=>{
//     console.log("Server is listening....")
// })


const http=require("http")
const server=http.createServer((req,res)=>{
  if(req.url==='/' && req.method==="GET"){
    res.end("You are at home page.");
  }
  else{
    res.statusCode=404;
    res.end("end");
  }
})

server.listen(8000,()=>{
    console.log("server started");
})