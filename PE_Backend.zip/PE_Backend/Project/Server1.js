// const http = require("http");
// const Port = 4000;
// const server = http.createServer((req, res) => {
//     if (req.url === "/user" && req.method === "GET") {
//         const user = {
//             name: "Manish",
//             id:12,
//             age: 20,
//             college:KIET
//         };
//         res.statusCode = 200;
//         res.end(JSON.stringify(user));
//     }
// });

// server.listen(Port, () => {
//     console.log("Server is listening...");
// });


const http = require("http"); // Import http built in module
const Port = 5000; // Assign a port number 
const server = http.createServer((req, res) => { // inside http module there is a method called createServer
    if (req.url === '/users' && req.method === "POST") {
        let body = '';
        req.on('data', (chunk) => {
            body += chunk;
        });

        req.on('end', () => {
            console.log("Raw Data:", body);
            const user = JSON.parse(body);
            console.log("User:", user);
            res.writeHead(200, {
                'Content-Type': 'application/json'
            });
            res.end(JSON.stringify({
                message: "user created successfully",
                user: user
            }));
        });
    } else {
        res.end("hello");
    }
});

    server.listen(Port, () => {
    console.log("Server running .........");
});
