// const math=require('./calculator') // cjs
// import {add,subtract,multiply,divide} from "./calculator.js"
import * as math from "./calculator.js"
console.log(math.add(2,3));
console.log(math.subtract(2,3));

