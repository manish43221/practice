const buffer=Buffer.from("hello students") //Create buffer with provided string
console.log(buffer)// print buffer in encoded form
console.log(buffer.toString())// buffer printing in actual string
console.log(buffer.length)// buffer length 

const buffer2=Buffer.alloc(20) // creating buffer with size
console.log(buffer2)
console.log(buffer2[0])
console.log(String.fromCharCode(buffer[4]))

