const fs=require('fs')
const FilePath="./test.txt"
const Content="Hi I am learning backend"
fs.writeFileSync(FilePath,Content)  // it will create file if not exists
//writing file async
console.log("Bye")
fs.writeFile("./test1.txt","This is the second file",(err)=>{
    if(err) throw err
    console.log("I am in a file")
})
console.log("I an out of file")
