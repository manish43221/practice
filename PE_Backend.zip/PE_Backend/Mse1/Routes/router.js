// const express=require("express");
// const router=express.Router();


// let polls = [
//     {
//         id: 1,
//         question: "Which programming language do you prefer?",
//         choices: [
//             { id: 1, text: "Java", count: 0 },
//             { id: 2, text: "C++", count: 0 },
//             { id: 3, text: "Python", count: 0 },
//             { id: 4, text: "JavaScript", count: 0 }
//         ]
//     },
//     {
//         id: 2,
//         question: "Which database do you prefer?",
//         choices: [
//             { id: 1, text: "MongoDB", count: 0 },
//             { id: 2, text: "MySQL", count: 0 },
//             { id: 3, text: "PostgreSQL", count: 0 }
//         ]
//     }
// ];

// router.get('/polls',(req,res)=>{
//     res.status(200).json({
//         message:"Polls retrieved successfully",
//         polls:polls
//     });
// });

// router.get('/polls/:id',(req,res)=>{
//     const id=parseInt(req.params.id);
//     const poll=polls.find(s=>s.id===id);
//     if(!poll){
//        return res.status(404).json({
//             message:"Not found"
//         });
//     }
//     res.status(200).json({
//         poll:poll
//     });
// })


// router.post('/vote',(req,res)=>{
//     const pollId=parseInt(req.body.pollId);
//     const optionId=parseInt(req.body.optionId);

//      if (pollId === undefined || optionId === undefined) {
//         return res.status(400).json({
//             message: "pollId and optionId are required"
//         });
//     }

//     const poll=polls.find(p=>p.id===pollId);
//     if(!poll){
//        return res.status(404).json({
//             message:"Poll not found"
//         })
//     }
//       const option = poll.choices.find(
//         choice => choice.id === optionId
//     );

//     if (!option) {
//         return res.status(400).json({
//             message: "Invalid option"
//         });
//     }

//     option.count++;

//     res.status(200).json({
//         message: "Vote recorded successfully",
//         poll: poll
//     });
// })

// router.get('/polls/:id/results',(req,res)={
//     const id = parseInt(req.params.id);

//     const poll = polls.find(p => p.id === id);

//     if (!poll) {
//         return res.status(404).json({
//             message: "Poll not found"
//         });
//     }

//     const totalResponses = poll.choices.reduce(
//         (total, choice) => total + choice.count,
//         0
//     );

//     res.status(200).json({
//         pollId: poll.id,
//         question: poll.question,
//         results: poll.choices.map(choice => ({
//             optionId: choice.id,
//             option: choice.text,
//             count: choice.count
//         })),
//         totalResponses: totalResponses
//     });
// })

// module.exports=router



// let products = [
//     {
//         id: 1,
//         name: "Laptop",
//         ratingCount: 0,
//         ratingTotal: 0,
//         averageRating: 0
//     },
//     {
//         id: 2,
//         name: "Mobile Phone",
//         ratingCount: 0,
//         ratingTotal: 0,
//         averageRating: 0
//     },
//     {
//         id: 3,
//         name: "Headphones",
//         ratingCount: 0,
//         ratingTotal: 0,
//         averageRating: 0
//     }
// ];

// router.get('/products',(req,res)=>{
//     res.status(200).json({
//         message:"Products retrived successfully",
//         products:products
//     })
// })

// router.post('/rate',(req,res)=>{
//     const idd=parseInt(req.body.id);
//     const rating=parseInt(req.body.rating);

//     if(idd===undefined || rating===undefined){
//         return res.status(400).json({
//             message:"productId and rating are required"
//         });
//     }
//      const product=products.find(p=>p.id===idd);
//      if(!product){
//         return res.status(404).json({
//             message:"Product not found"
//         });
//      }
//       if (
//         !Number.isNaN(rating) ||
//         rating < 1 ||
//         rating > 5
//     ) {
//         return res.status(400).json({
//             message: "Rating must be between 1 and 5"
//         });
//     }
//     product.ratingCount++;
//     product.ratingTotal += numericRating;

//     product.averageRating =
//         product.ratingTotal / product.ratingCount;

//     res.status(200).json({
//         message: "Rating submitted successfully",
//         product: product
//     });
// })

// router.get('/ratings',(req,res)=>{
//     const ratings = products.map(product => ({
//         name: product.name,
//         ratingCount: product.ratingCount,
//         averageRating: product.averageRating
//     }));

//     res.status(200).json({
//         message: "Product ratings retrieved successfully",
//         ratings: ratings
//     });
// })
// module.exports=router;




// let events = [
//     {
//         id: 1,
//         name: "Web Development Workshop",
//         date: "2026-09-25",
//         registrationCount: 0
//     },
//     {
//         id: 2,
//         name: "Machine Learning Workshop",
//         date: "2026-09-27",
//         registrationCount: 0
//     },
//     {
//         id: 3,
//         name: "Cyber Security Workshop",
//         date: "2026-09-30",
//         registrationCount: 0
//     }
// ];


// router.get("/events", (req, res) => {
//     res.status(200).json({
//         message: "Events retrieved successfully",
//         events: events
//     });
// });

// router.post('/register',(req, res)=>{
//     const eventId=parseInt(req.params.id);
//     if(eventId===undefined){
//         return res.status(400).json({
//             message:"Event not found"
//         });
//     }
//     const event=events.find(s=>s.id===eventId);
//     if(!event){
//         return res.status(404).json({
//             message:"Not found"
//         });
//     }
//     event.registrationCount++;
//     res.status(200).json({
//         message:"Registration successfull",
//         product:product
//     })
// })

// router.get("/events/:id", (req, res) => {
// const id = parseInt(req.params.id);
//     const event = events.find(
//         e => e.id === id
//     );
//     if (!event) {
//         return res.status(404).json({
//             message: "Event not found"
//         });
//     }
//     res.status(200).json({
//         event: event
//     });
// });


// router.post('/cancel',(req,res)=>{
//     const eventId=parseInt(req.parama.id);
//     if(eventId===undefined){
//         return res.status(400).json({
//             message:"Invalid id"
//         });
//     }

//      const event = events.find(
//         e => e.id === eventId
//     );

//     if (!event) {
//         return res.status(404).json({
//             message: "Event not found"
//         });
//     }

//     if (event.registrationCount <= 0) {
//         return res.status(400).json({
//             message: "No registrations to cancel"
//         });
//     }


//     event.registrationCount--;

//     res.status(200).json({
//         message: "Registration cancelled successfully",
//         event: event
//     });
// });


// module.exports = router;






// let links = [];
// let nextId = 1;

// function generateCode() {
//     return Math.random().toString(36).substring(2, 8);
// }

// router.post('/shorten',(req,res)=>{
//     const userName=req.body.userName;
//     const originalUrl=req.body.originalUrl;

//     if (!userName || !originalUrl) {
//         return res.status(400).json({
//             message: "username and originalUrl are required"
//         });
//     }
//     let url;
//     try{
//         url=new URL(originalUrl)
//     }
//     catch(error){
//         return res.status(400).json({
//             message: "Invalid URL"
//         });
//     }
//     if (url.protocol !== "http:" && url.protocol !== "https:") {
//         return res.status(400).json({
//             message: "Invalid URL"
//         });
//     }

//     let code = generateCode();

//     while (links.some(link => link.code === code)) {
//         code = generateCode();
//     }

//     const newLink = {
//         id: nextId++,
//         userName: userName,
//         originalUrl: originalUrl,
//         code: code
//     };

//     links.push(newLink);

//     res.status(201).json({
//         message: "URL shortened successfully",
//         code: code
//     });

// })


// router.get("/url/:code", (req, res) => {
//     const code = req.params.code;
//     const link = links.find(
//         link => link.code === code
//     );

//     if (!link) {
//         return res.status(404).json({
//             message: "URL not found"
//         });
//     }

//     res.status(200).json({
//         originalUrl: link.originalUrl,
//         creator: link.username
//     });
// });



// router.get("/users/:username/urls", (req, res) => {

//     const username = req.params.username;
//     const userLinks = links.filter(
//         link => link.username === username
//     );

//     res.status(200).json({
//         username: username,
//         urls: userLinks
//     });
// });


// router.delete("/url/:code", (req, res) => {
//     const code = req.params.code;
//     const index = links.findIndex(
//         link => link.code === code
//     );

//     if (index === -1) {
//         return res.status(404).json({
//             message: "URL not found"
//         });
//     }
//     links.splice(index, 1);

//     res.status(200).json({
//         message: "URL deleted successfully"
//     });
// });


// module.exports = router;





// let tasks = [];

// let nextId = 1;

// const validStatuses = [
//     "pending",
//     "in-progress",
//     "completed"
// ];


// router.get('/tasks',(req,res)=>{
//     res.status(200).json({
//         message:"retrieved successfull",
//         tasks:tasks
//     });
// })

// router.post('/tasks',(req,res)=>{
//     const title=req.body.title;
//     const status=req.body.status;

//     if(!status || !title || !validStatuses.includes(status)){
//         return res.status(400).json({
//             message:"Please provide valid task details"
//         });
//     }
//     const newTask={
//         id:nextId++,
//         title:title,
//         status:status
//     }

//     tasks.push(newTask);
//     res.status(200).json({
//         message:"added",
//         task:newTask
//     })

// })

// router.patch('/tasks/:id',(req,res)=>{
//     const id=parseInt(req.params.id);
//      const task = tasks.find(task => task.id === id);

//      if(!task){
//         return res.status(400).json({
//             message:"task not found"
//         });
//      }
// const title=req.body.title
// const status=req.body.status

//     if (
//         status !== undefined &&
//         !validStatuses.includes(status)
//     ) {
//         return res.status(400).json({
//             message: "Please provide valid task details"
//         });
//     }

//     // Update only supplied fields
//     if (title !== undefined) {
//         if (!title) {
//             return res.status(400).json({
//                 message: "Please provide valid task details"
//             });
//         }

//         task.title = title;
//     }

//     if (status !== undefined) {
//         task.status = status;
//     }

//     res.status(200).json({
//         message: "Task updated successfully",
//         task: task
//     });

// });


// // DELETE /api/tasks/:id
// router.delete("/tasks/:id", (req, res) => {

//     const id = Number(req.params.id);

//     const index = tasks.findIndex(
//         task => task.id === id
//     );

//     if (index === -1) {
//         return res.status(404).json({
//             message: "Task not found"
//         });
//     }

//     tasks.splice(index, 1);

//     res.status(200).json({
//         message: "Task deleted successfully"
//     });

// });


// // GET /api/tasks/status/:status
// router.get("/tasks/status/:status", (req, res) => {

//     const status = req.params.status;

//     // Optional validation of status
//     if (!validStatuses.includes(status)) {
//         return res.status(400).json({
//             message: "Invalid task status"
//         });
//     }

//     const filteredTasks = tasks.filter(
//         task => task.status === status
//     );

//     res.status(200).json({
//         status: status,
//         tasks: filteredTasks
//     });

// });


// module.exports = router;




// router.post('/simpleinterest',(req,res)=>{
//     const p=parseInt(req.body.p);
//     const r=parseInt(req.body.r);
//     const t=parseInt(req.body.t);

//     if(!p || !r || !t || isNaN(p) || isNaN(r) || isNaN(t) || p<=0 || r<=0 || t<=0){
//         return res.status(400).json({
//             message:"Invalid input"
//         })
//     }
//      const interest = (p * r * t) / 100;

//     res.status(200).json({
//         interest: interest
//     });
// })


// router.post('/compoundinterest',(req,res)=>{
//     const p=parseInt(req.body.p);
//     const r=parseInt(req.body.r);
//     const t=parseInt(req.body.t);

//     if(!p || !r || !t || isNaN(p) || isNaN(r) || isNaN(t) || p<=0 || r<=0 || t<=0){
//         return res.status(400).json({
//             message:"Invalid input"
//         })
//     }
//       const amount = p * Math.pow(1 + r / 100, t);

//     const compoundInterest = amount - p;

//     res.status(200).json({
//         compoundInterest: compoundInterest
//     });
// })


// router.post("/area", (req, res) => {

//     const shape=parseInt(req.body.shape);
//     const radius=parseInt(req.body.radius);
//     const length=parseInt(req.body.length);
//     const width=parseInt(req.body.width);
//     const side=parseInt(req.body.side);

//     if (!shape) {
//         return res.status(400).json({
//             message: "Please provide valid input"
//         });
//     }

//     let area;

//     // Circle
//     if (shape === "circle") {

//         const r =radius;

//         if (
//             radius === undefined ||
//             !Number.isFinite(r) ||
//             r <= 0
//         ) {
//             return res.status(400).json({
//                 message: "Please provide valid input"
//             });
//         }

//         area = Math.PI * r * r;
//     }

//     // Rectangle
//     else if (shape === "rectangle") {

//         const l = length;
//         const w = width;

//         if (
//             length === undefined ||
//             width === undefined ||
//             isNaN(l) ||
//             isNaN(w) ||
//             l <= 0 ||
//             w <= 0
//         ) {
//             return res.status(400).json({
//                 message: "Please provide valid input"
//             });
//         }

//         area = l * w;
//     }

//     // Square
//     else if (shape === "square") {

//         const s = side;

//         if (
//             side === undefined ||
//             isNaN(s) ||
//             s <= 0
//         ) {
//             return res.status(400).json({
//                 message: "Please provide valid input"
//             });
//         }

//         area = s * s;
//     }

//     // Unsupported shape
//     else {
//         return res.status(400).json({
//             message: "Please provide valid input"
//         });
//     }

//     res.status(200).json({
//         shape: shape,
//         area: area
//     });
// });


// module.exports = router;



// let students = [
//     {
//         id: 1,
//         name: "Rahul",
//         present: 0,
//         absent: 0
//     },
//     {
//         id: 2,
//         name: "Aman",
//         present: 0,
//         absent: 0
//     },
//     {
//         id: 3,
//         name: "Priya",
//         present: 0,
//         absent: 0
//     }
// ];

// router.get('/students',(req,res)=>{
//     res.status(200).json({
//         message:"Students retrived ",
//         students:students
//     })
// })

// router.post('/attendance',(req,res)=>{
//     const studentId=parseInt(req.body.studentId);
//     const status=req.body.status;

//     if(studentId===undefined || status===undefined){
//         return res.status(400).json({
//             message:"Invalid input"
//         });
//     }
//   const student=students.find(s=>s.id===studentId);
//   if(!student){
//      return res.status(404).json({
//             message: "Student not found"
//         });
//   }
   
//   if (status !== "present" && status !== "absent") {
//         return res.status(400).json({
//             message: "Invalid attendance status"
//         });
//     }

//     if (status === "present") {
//         student.present++;
//     } else {
//         student.absent++;
//     }

//     res.status(200).json({
//         message:"added",
//         student:student
//     })
// })

// router.get("/attendance/:studentId", (req, res) => {
//     const studentId = parseInt(req.params.studentId);
//     const student = students.find(
//         s => s.id === studentId
//     );
//     if (!student) {
//         return res.status(404).json({
//             message: "Student not found"
//         });
//     }
//     const totalClasses = student.present + student.absent;
//     res.status(200).json({
//         studentId: student.id,
//         name: student.name,
//         present: student.present,
//         absent: student.absent,
//         totalClasses: totalClasses
//     });

// });

// router.get('/attendance',(req,res)=>{
//     let totalpresent=0;
//     let totalabsent=0;

//     students.forEach(s=>{
//         totalpresent+=s.present;
//         totalabsent+=s.absent;
//     });

//     const totalrecords=totalpresent+totalabsent;
//     res.status(200).json({
//         present:totalpresent,
//         absent:totalabsent,
//         totalrecords:totalrecords
//     })
// })



// let expenses=[]
// let nextId=1;

// router.get('/expenses',(req,res)=>{
//     res.status(200).json({
//         message:"Retrived successfull",
//         expenses:expenses
//     })
// })

// router.post('/expenses',(req,res)=>{
//     const title=req.body.title;
//     const amount=parseInt(req.body.amount)
//     const category=req.body.category

//     if (
//         title === undefined ||
//         amount === undefined ||
//         category === undefined ||
//         title === "" ||
//         category === "" ||
//         isNaN(amount) ||
//         amount <= 0
//     ) {
//         return res.status(400).json({
//             message: "Please provide valid expense details"
//         });
//     }
//   const newexpense={
//     id:nextId++,
//      title: title,
//     amount: ActiveXObjectmount,
//     category: category
//   }
// expenses.push(newexpense)
//   res.status(200).json({
//     message:"added",
//     newexpense:newexpense
//   })
// })


// router.get("/expenses/category/:category", (req, res) => {
//     const category = req.params.category;
//     const res=expenses.filter(exp=>exp.category===category)

//     res.status(200).json({
//         expenses: res
//     });

// });

// router.get('/expenses/summary',(req,res)=>{
//     let total=0
//     expenses.forEach(expense=>{
//         total+=expense.amount;
//     });

//     res.status(200).json({
//         total:total,
//         numberofexp:expenses.length
//     });
// })

// router.delete('/expenses/:id',(req,res)=>{
//     const id=parseInt(req.params.id);
//     const expense=expenses.findIndex(e=>e.id===id);
//     if(expense===-1){
//         return res.status(404).json({
//             message:"not found",
//         });
//     }

//     const deleted=expenses.splice(expense,1);
//     res.status(200).json({
//         message:"deleted",
//         deleted:deleted[0]
//     })
// })



// let books = [
//     {
//         id: 1,
//         title: "Java Programming",
//         author: "James Gosling",
//         available: true
//     },
//     {
//         id: 2,
//         title: "Clean Code",
//         author: "Robert Martin",
//         available: true
//     },
//     {
//         id: 3,
//         title: "Data Structures",
//         author: "Mark Allen",
//         available: true
//     }
// ];

// router.get('/books',(req,res)=>{
//     res.status(200).json({
//         message:"Retrieved successfull",
//         books:books
//     });
// })

// router.get('/books/:id',(req,res)=>{
//     const id=parseInt(req.params.id);
//     const book=books.find(s=>s.id===id);
//     if(!book){
//         return res.status(404).json({
//             message:"book not found"
//         })
//     }
//     res.status(200).json(book);
// })

// router.post('/books',(req,res)=>{
//     const title=req.body.title;
//     const author=req.body.author;
//     if(title===undefined || author===undefined){
//         return res.status(404).json({
//             message:"invalid"
//         })
//     }
//     const book={
//         id:books.length+1,
//          title: title,
//         author: author,
//         available: true
//     }
//     books.push(book);
//     res.status(200).json({
//         message:"book added",
//         book:book
//     })
// })

// router.post("/books/issue", (req, res) => {

//     const bookId=parseInt(req.body.bookId);

//     if (bookId === undefined) {
//         return res.status(400).json({
//             message: "bookId is required"
//         });
//     }


//     const book = books.find(
//         book => book.id === bookId
//     );

//     if (!book) {
//         return res.status(404).json({
//             message: "Book not found"
//         });
//     }

//     if (!book.available) {
//         return res.status(400).json({
//             message: "Book is already issued"
//         });
//     }

//     book.available = false;

//     res.status(200).json({
//         message: "Book issued successfully",
//         book: book
//     });

// });


// router.post('/books/return',(req,res)=>{
//     const bookId=parseInt(req.params.id);
//     if(bookId===undefined){
//         return res.status(400).json({
//             message:"Invalid input"
//         });
//     }
//     const book=books.find(e=>e.id===bookId);
//     if(!book){
//         return res.status(404).json({
//             message:"Book not found"
//         });
//     }
//     book.available=true;
//     res.status(200).json({
//         message:"added",
//         book:book
//     })
// })



// const questions = [
//     {
//         id: 1,
//         question: "How satisfied are you with the service?",
//         choices: [
//             { id: 1, text: "Very Satisfied" },
//             { id: 2, text: "Satisfied" },
//             { id: 3, text: "Neutral" },
//             { id: 4, text: "Dissatisfied" }
//         ]
//     },
//     {
//         id: 2,
//         question: "How easy was the service to use?",
//         choices: [
//             { id: 1, text: "Very Easy" },
//             { id: 2, text: "Easy" },
//             { id: 3, text: "Difficult" },
//             { id: 4, text: "Very Difficult" }
//         ]
//     },
//     {
//         id: 3,
//         question: "Would you recommend our service?",
//         choices: [
//             { id: 1, text: "Yes" },
//             { id: 2, text: "No" }
//         ]
//     }
// ];


// // Store submitted feedback
// let feedback = [];

// router.get('/questions',(req,res)=>{
//     res.status(200).json({
//      questions:questions
//     })
// })



// router.post("/feedback", (req, res) => {

//     const { userId, responses } = req.body;

//     // Basic validation
//     if (
//         userId === undefined ||
//         userId === "" ||
//         !Array.isArray(responses) ||
//         responses.length === 0
//     ) {
//         return res.status(400).json({
//             message: "Please provide valid feedback"
//         });
//     }

//     // Validate every response before storing anything
//     for (const response of responses) {

//         if (
//             response === null ||
//             response.questionId === undefined ||
//             response.optionId === undefined
//         ) {
//             return res.status(400).json({
//                 message: "Please provide valid feedback"
//             });
//         }

//         const question = questions.find(
//             q => q.id === Number(response.questionId)
//         );

//         // Question must exist
//         if (!question) {
//             return res.status(400).json({
//                 message: "Please provide valid feedback"
//             });
//         }

//         // Option must belong to the selected question
//         const option = question.choices.find(
//             choice => choice.id === Number(response.optionId)
//         );

//         if (!option) {
//             return res.status(400).json({
//                 message: "Please provide valid feedback"
//             });
//         }
//     }


//     // Store only after all validation succeeds
//     const submission = {
//         userId: userId,
//         responses: responses.map(response => ({
//             questionId: Number(response.questionId),
//             optionId: Number(response.optionId)
//         }))
//     };

//     feedback.push(submission);

//     res.status(201).json({
//         message: "Feedback submitted successfully",
//         feedback: submission
//     });

// });


// router.get("/feedback/:userId", (req, res) => {

//     const userId = req.params.userId;

//     const userFeedback = feedback.filter(
//         item => String(item.userId) === String(userId)
//     );

//     res.status(200).json({
//         userId: userId,
//         feedback: userFeedback
//     });

// });

// router.get("/feedback/summary", (req, res) => {

//     const summary = [];

//     questions.forEach(question => {

//         const questionSummary = {
//             questionId: question.id,
//             question: question.question,
//             choices: []
//         };

//         question.choices.forEach(choice => {

//             let count = 0;

//             feedback.forEach(submission => {

//                 submission.responses.forEach(response => {

//                     if (
//                         response.questionId === question.id &&
//                         response.optionId === choice.id
//                     ) {
//                         count++;
//                     }

//                 });

//             });

//             questionSummary.choices.push({
//                 optionId: choice.id,
//                 option: choice.text,
//                 count: count
//             });

//         });

//         summary.push(questionSummary);
//     });

//     res.status(200).json({
//         summary: summary
//     });

// });


// module.exports = router;



// let candidates = [
//     {
//         id: 1,
//         name: "Rahul",
//         votes: 0
//     },
//     {
//         id: 2,
//         name: "Aman",
//         votes: 0
//     },
//     {
//         id: 3,
//         name: "Priya",
//         votes: 0
//     }
// ];

// router.get('/candidates',(req,res)=>{
//     res.status(200).json({
//         candidates:candidates
//     })
// })

// router.post('/vote',(req,res)=>{
//     const candidateId=parseInt(req.params.candidateId);
//     if(candidateId===undefined){
//         return res.status(400).json({
//             message:"invalid"
//         });
//     }
//     const cand=candidates.find(e=>e.id===candidateId);
//     if(!cand){
//         return res.status(404).json({
//             message:"not found"
//         })
//     }
//     cand.votes++;
//     res.json({
//         cand:cand
//     });
// })

// router.get('/result',(req,res)=>{
//     let total=0;
//     candidates.forEach(cand=>{
//         total+=cand.votes;
//     });
//     res.json({
//         total:total
//     });

// })
// module.exports =router