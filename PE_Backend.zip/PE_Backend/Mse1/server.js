const express=require("express")
const app=express()
app.use(express.json())

const communityRoutes=require('./Routes/router.js')
app.use('/api',communityRoutes);

app.listen(8000,()=>{
    console.log("server started");
})