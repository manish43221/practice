const fs=require("fs")
const res=fs.readFileSync("./test.txt");
fs.writeFileSync("./test3.txt",res)
