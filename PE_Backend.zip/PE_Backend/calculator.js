export   function add(a, b) { // esm type
    return a+b;
}

export   function subtract(a, b) {
    return a-b;
}

export function multiply(a, b) {
    return a*b;
}

 export  function divide(a, b) {
    if (b == 0) {
        return 0;
    } else {
        return a / b;
    }
}

// module.exports={add,subtract,multiply,divide} // cjs type
