const express=require('express')
const app=express()
const PORT=4000


// //Application leval middleware

// // 1. Next Middleware use
// app.use((req,res,next)=>{
//     console.log("Middleware 1")
//     next();
// })

// app.use((req,res,next)=>{
//     console.log("Middleware 2")
//     next();
// })


// // 2.Mount on path
// app.use('/student/:id',(req,res,next)=>{
//     console.log("Response type",req.method);
// })

// //Router level Middleware
// app.get('/student',(req,res)=>{
//     console.log("Router Middleware");
//     res.send("Home Page")
// })


//Multiple Route Handler

// app.use('/user/:id',
//     (req,res,next)=>{
//     console.log("Requested URL",req.url);
//     next();

// },
// (req,res,next)=>{
//     console.log("Request type",req.method);
//     res.end("Ended")
// }
// )
app.use(express.json())
app.use(express.urlencoded({ extended: true }));



app.post('/user', (req, res) => { 
    console.log(req.body); 
    res.send("User data received");
 });


app.use('/student/:id',(req,res,next)=>{
    if(req.params.id==='0')
        next('route')
    else
        next()
})

app.get('/student/:id',(req,res)=>{
    res.send("Special Route here")

})


//Error handling Middleware

app.use((err,req,res,next)=>{
    console.error(err.stack)
    res.status(500).send("Error")
})

app.listen(PORT,()=>{
    console.log("Server started");
})


