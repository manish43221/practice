const User = require("../models/usermodels.js");
const bcrypt = require("bcryptjs");
const jwt=require("../util/jwt.js");
const {generateToken,generateTokenRefresh} = require("../util/jwt.js");
const cookie=require('cookie-parser');

const loginUser=async (req,res)=>{
     try{
    const {email,password}=req.body
    if(!email || !password) return res.status(400).json({ message: "email and pass required"})
    const ExistingUser=await User.findOne({email:email})
    if(!ExistingUser) return res.status(404).json({message:"not found"})

    const comparePass=await bcrypt.compare(password,ExistingUser.password);
    if(!comparePass) return res.status(400).json({ message:"password not matched"})
   
    
//tokens

    const token =generateToken(ExistingUser);
    res.cookie('token',token,{
        httponly:true,
        secure:process.env.SECRET_KEY,
        sameSite:"strict",
        maxAge:3600000
    })


    const refreshToken=generateTokenRefresh(ExistingUser)
    const hashed=await bcrypt.hash(refreshToken,10)
    ExistingUser.refreshToken=hashed
    ExistingUser.save()



   return  res.status(200).json({
        message:"login successful",
       user:{
        username:ExistingUser.username,
        email:ExistingUser.email
       }})

    }catch(error){
      return   res.status(500).json({
            message:"server error"
        })
    }
}

module.exports=loginUser