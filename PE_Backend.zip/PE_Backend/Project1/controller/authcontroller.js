const User = require("../models/usermodels.js");
const bcrypt = require("bcryptjs");
const jwt=require("../util/jwt.js")

const regUser=async (req,res) => {
    try {
        const { name, email, password } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ message:"data not found" });
        }
        const user = await User.findOne({name:name,email:email});
        if (user) {
            return res.status(409).json({ message: "user already exists" });
        }
        const hashPassword = await bcrypt.hash(password, 10);
        await User.create({
            name,
            email,
            password: hashPassword
        });
        return res.status(201).json({ message: "New user created" });
    } catch (error) {
        console.error("User registration failed:", error);
        return res.status(500).json({ message: "server error" });
    }
}

module.exports = regUser
