const jwt = require('jsonwebtoken')

const logoutUser = (req,res) => {
    const {token} =req.cookies.token
    if(!token){
        return res.status(404).json({
            message:"Token not found"
        })
    }

        res.clearCookie('token')
        return res.status(200).json({
            message: "Logout is successfully done"
        })
    
}


module.exports=logoutUser