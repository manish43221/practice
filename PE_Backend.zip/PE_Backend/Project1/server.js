require('dotenv').config()
const express = require('express')
const cookieParser = require('cookie-parser')
const mongooseconnect = require('./db/db.js')
const studentRoutes = require('./Routes/studentRoutes')
const authRoutes = require('./Routes/authRoute.js')
const helmet=require("helmet");

const app = express()

app.use(express.json())
app.use(cookieParser())
app.use(helmet());
// app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000

app.use(mongooseconnect)

app.use('/students', studentRoutes)
app.use('/authroute', authRoutes)

app.listen(PORT, () => {
    console.log('Server started successfully...')
})


