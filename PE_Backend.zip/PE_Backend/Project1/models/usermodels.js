const mongoose=require("mongoose")
const userSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true,
        unique:true
    },
    email:{
        type:String,
        required:true,
        unique:true

    },
    password:{
        type:String,
        required:true
    },
    role:{
        type:String,
        enum:['student','admin','teacher'],
        default:"student"
    },
    refreshToken:{
        type:String
    }
})
const user = mongoose.model('user', userSchema);
module.exports = user;
