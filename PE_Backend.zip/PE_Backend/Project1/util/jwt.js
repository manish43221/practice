const jwt=require('jsonwebtoken');

const generateToken=(user)=>{
  return   jwt.sign(
        {
            id:user_id,
            email:user_email
        },
        process.env.SECRET_KEY,
        {
            expiresIn:'1h'
        }
    )
}

const generateTokenRefresh=(user)=>{
return jwt.sign(
    {
        id:user_id
    },
        process.env.SECRET_KEY_REFRESH,
        {
            expiresIn:'24h'
        }
)
}

module.exports={generateToken,generateTokenRefresh}

