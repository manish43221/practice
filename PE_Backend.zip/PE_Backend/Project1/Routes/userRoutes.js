const express = require('express')
const router = express.Router()

// const checkroles = require('../middleware/roleMiddleware.js')
const User = require('../models/usermodels.js')
const {route} =require('./studentRoutes.js')


router.get('/',(req,res)=>{
    const {token}=req.cookies
    if(!token) res.status(400).json({message:"user not logged in"})
})

router.post('/createUser',async (req,res)=>{
    const {name, email ,password}=req.body
    if(!name || !email || !password) req.statusCode(400).json({ message: "data not found"})

    const user=await User.find({name:name,email:email})
    if(user){
       return  res.status(200).json({
            message:"user already exists"
        })
    }
    const hashPassword=await bcrypt.hash(password,10);
    const newUser=User.create({
        name:name,
        email:email,
        password:hashPassword
    })
  if(!newUser) res.status(400).json({message:"something went wrong"})
return  res.status(200).json({
    message:"New user created",
 })

})

router.post('/login',async(req,res)=>{
    try{
    const {email,password}=req.body
    if(!email || !password) return res.status(400).json({ message: "email and pass required"})
    const ExistingUser=await User.findOne({email:email})
    if(!ExistingUser) return res.status(404).json({message:"not found"})

    const comparePass=await bcrypt.compare(password,ExistingUser.password);
    if(!comparePass) return res.status(400).json({ message:"password not matched"})
   
 return  res.status(200).json({
        message:"login successful",
       user:{
        username:ExistingUser.username,
        email:ExistingUser.email
       }
   }
)

    }catch(error){
      return   res.status(500).json({
            message:"server error"
        })
    }
})

module.exports=User