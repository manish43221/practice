const express = require('express')
const router = express.Router()
const checkroles = require('../middleware/roleMiddleware.js')
const Student = require('../models/studentModels.js')
const auth=require('../middleware/authMiddleware.js');
const authMiddleware = require('../middleware/authMiddleware.js');

router.use((req, res, next) => {
    console.log("You are at Student Route")
    next()
})

router.use(auth)
// GET ALL STUDENTS
router.get('/', checkroles('teacher', 'student', 'admin'), async (req, res) => {
    try {
        const students = await Student.find()

        res.json(students)
    }
    catch (error) {
        res.status(503).json({
            message: "Student not found",
            error: error.message
        })
    }
})


// GET STUDENT BY ID
router.get('/:id', checkroles('teacher', 'student', 'admin'), async (req, res) => {
    try {
        const id = req.params.id

        const student = await Student.findById(id)

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            })
        }

        res.json(student)
    }
    catch (error) {
        res.status(503).json({
            message: "Error finding student",
            error: error.message
        })
    }
})


// SEARCH STUDENT BY COURSE AND AGE
router.get('/search', checkroles('teacher', 'student', 'admin'), async (req, res) => {
    try {
        const course = req.query.course
        const age = parseInt(req.query.age)

        const students = await Student.find({
            course: course,
            age: age
        })

        if (students.length === 0) {
            return res.status(404).json({
                message: "Student not found"
            })
        }

        res.json(students)
    }
    catch (error) {
        res.status(503).json({
            message: "Error searching student",
            error: error.message
        })
    }
})


// ADD STUDENT
router.post('/', checkroles('teacher', 'admin'), async (req, res) => {
    try {
        const newStudent = new Student({
            name: req.body.name,
            age: req.body.age,
            course: req.body.course
        })

        const savedStudent = await newStudent.save()

        res.status(201).json({
            message: "Student added",
            student: savedStudent
        })
    }
    catch (error) {
        res.status(503).json({
            message: "Student could not be added",
            error: error.message
        })
    }
})


// DELETE STUDENT
router.delete('/:id', checkroles('admin'), async (req, res) => {
    try {
        const id = req.params.id

        const student = await Student.findByIdAndDelete(id)

        if (!student) {
            return res.status(404).json({
                message: "Student not found"
            })
        }

        res.json({
            message: "Student deleted",
            student: student
        })
    }
    catch (error) {
        res.status(503).json({
            message: "Error deleting student",
            error: error.message
        })
    }
})


// UPDATE STUDENT - PUT
router.put('/:id', checkroles('teacher', 'admin'), async (req, res) => {
    try {
        const id = req.params.id

        const student = await Student.findByIdAndUpdate(
            id,
            {
                name: req.body.name,
                age: req.body.age,
                course: req.body.course
            },
            {
                new: true
            }
        )

        if (!student) {
            return res.status(404).json({
                message: "No record found"
            })
        }

        res.json(student)
    }
    catch (error) {
        res.status(503).json({
            message: "Error updating student",
            error: error.message
        })
    }
})


// PARTIAL UPDATE STUDENT - PATCH
router.patch('/:id', checkroles('teacher', 'admin'), async (req, res) => {
    try {
        const id = req.params.id

        const student = await Student.findByIdAndUpdate(
            id,
            req.body,
            {
                new: true
            }
        )

        if (!student) {
            return res.status(404).json({
                message: "No record found"
            })
        }

        res.json(student)
    }
    catch (error) {
        res.status(503).json({
            message: "Error updating student",
            error: error.message
        })
    }
})


module.exports = router