const express=require("express")
const router=express.Router()
const regUser =require('../controller/authcontroller.js')
const loginUser=require('../controller/logincontroller.js')
const logoutUser=require('../controller/logoutcontroller.js')

router.post('/register',regUser)
router.post('/login',loginUser)
router.post('/logout',logoutUser)

module.exports=router
