const checkroles=(...allowedroles)=>{
    return (req,res,next)=>{
    const role=req.headers.role
    if(!req.user){
        return res.status(404).json({
            message:"No role provided"
        })
    }
  if(allowedroles.includes(req.user.role)){
    next();
  }
  else{
    return res.status(403).json({
        message:"Not allowed"
    })
  }
   }
}
module.exports=checkroles


