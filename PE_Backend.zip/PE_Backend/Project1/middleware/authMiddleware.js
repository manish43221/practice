const jwt=require('jsonwebtoken')
const authMiddleware=(req,res,next)=>{
    try{
    const{token }=req.cookies
    if(!token) return res.status(400).json({ message: "not token found"})
    
    const ver=jwt.verify(token,process.env.SECRET_KEY)
    req.user=ver

}catch(error){
    console.log(error)
    return res.status(400).json({message:"Invalid token"})
}
}


module.exports=authMiddleware