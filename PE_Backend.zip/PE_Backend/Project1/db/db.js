const mongoose=require("mongoose")
const mongooseconnect=()=>{
    mongoose.connect(process.env.MONGODB_URL)
.then(()=>{
    console.log("Database connected.")
})
.catch((error)=>{
    console.log("Database not connected",error)
})

}
module.exports=mongooseconnect

