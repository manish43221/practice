import { useState } from "react";
import { useEffect } from "react";

function App() {
  const [title,setTitle] =useState("");
  const [tasks, setTasks] = useState([]);
  const API="http://localhost:5000/api/task"


async function getTask(){
  const response=await fetch(API);
  const data =await response.json();
  setTasks(data);
} 

useEffect(()=>{
 getTask();
},[])

async function addTask(e){
  e.preventDefault();
  if(!title.trim()) alert("Title missing")

  const response=await fetch(API,
    {
      method:"POST",
      headers:{"Content-type":"application/json"},
    },
    body.JSON.Stringify({title:title})
  )

if(!response.ok){
  alert(" ")
  return 
}

setTitle("");
getTask();
}

async function deleteTask(id){
  const response=await fetch(`${API}/${id}`,
    {
    method:"DELETE"
    })
   if (!response.ok) {
        alert("Failed to delete task");
        return;
      }
    getTask();
}

  return (
    <>
<h1>Task Manager</h1>
<form onSubmit={addTask}>
   <input
          type="text"
          placeholder="Enter title of task"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
    <button type="submit">Add Task</button>
</form>
<h2>List of Tasks</h2>
      {tasks.length === 0 ? (
        <p>No tasks found</p>
      ) : (
        <ul>
          {tasks.map((task) => (
            <li key={task._id}>
              {task.title}
              <button onClick={() => deleteTask(task._id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </>
  )
}


export default App

