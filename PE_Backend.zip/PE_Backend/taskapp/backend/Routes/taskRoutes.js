const express = require("express");
const router = express.Router();
const Task = require("../models/taskSchema");
const User = require("../models/userSchema");
const asyncHandler = require("../util/asyncHandler");
const { default: mongoose } = require("mongoose");


//Using skip and limit in mongodb
// router.get("/", asyncHandler(async (req, res) => {
//   const page=parseInt(req.query.page,10)|| 1;
//   const limit=parseInt(req.query.limit,10) || 10;
//   const santpage=page>1?page:1;
//   const santlimit=limit<1?10:limit;
//   const skip=(santpage-1)*santlimit;
//   const [tasks,totaltasks] = await Promise.all([Task.find().populate("user", "name email")
//     .sort({createdAt:-1}).skip(skip).limit(santlimit)
//     ,Task.countDocuments()]);

//   const totalpages=Math.ceil(totaltasks/santlimit);
//   res.json({
//     success:true,
//    metadata:{
//     curpage:santpage,
//     limit:santlimit,
//     totaltasks,
//     totalpages
//    },
//    data:tasks
//   });
// }));


//Using cursor 
router.get("/",asyncHandler(async (req,res)=>{
  const limit=parseInt(req.quert.limit,10)||10;
  const santlimit=limit<1?10:limit;  //step1: receive limit from frontend

  const {nextcursor}=req.query      // step2: receive cursor from client
  const query={ }     // step3: create empty query

//check if cursor value update than change database filter
if(nextcursor){
  query._id = { $lt: new mongoose.Type.ObjectId(nextcursor) };
}
const task=await Task.find(query).populate("user","name email")
.sort({_id:-1}).limit(santlimit+1)
const hasNext=task.length>santlimit
if(hasNext)
  task.pop()

const lastItem=task[task.length-1]
const newcursor=hasNext && lastItem ? lastItem._id:null

res.json({
  success:true,
  limit:santlimit,
  hasNext,
  nextcursor:newcursor,
  data:task
})
}))



router.post("/", asyncHandler(async (req, res) => {
  const { title, taskname, userId } = req.body;
  if (!title || !title.trim() || !taskname || !userId) {
    return res.status(400).json({
      message: "Title, taskname and userId are required"
    });
  }
  const existingUser = await User.findById(userId);
  if (!existingUser) {
    return res.status(404).json({
      message: "User not found"
    });
  }
  const task = await Task.create({
    title: title.trim(),
    taskname,
    user: existingUser._id
  });
  const savedTask = await task.populate("user", "name email");
  res.status(201).json(savedTask);
}));


router.post("/api/user", asyncHandler(async (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    return res.status(400).json({
      message: "Name and email are required"
    });
  }
  const user = await User.create({ name, email });
  res.status(201).json({
    message: "User creation is succeed.",
    user
  });
}));


router.put("/:id", asyncHandler(async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) {
    return res.status(404).json({
      message: "Task not found"
    });
  }
  task.done = !task.done;
  await task.save();
  res.json(task);
}));


router.delete("/:id", asyncHandler(async (req, res) => {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) {
    return res.status(404).json({
      message: "Task not found"
    });
  }
  res.json({
    message: "Task deleted"
  });
}));

module.exports = router;
