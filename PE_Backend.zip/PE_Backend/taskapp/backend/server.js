require('dotenv').config()
const mongoose=require('mongoose')
const express = require("express");
const cors = require("cors");
const taskRoutes = require("./Routes/taskRoutes");
const errorHandler = require("./middleware/errorHandler");
const rateLimit=require("express-rate-limit");

const PORT=5000
const app = express();
app.use(cors());
app.use(express.json());
const limit=rateLimit({
  windowMs:15*60*1000,
  limit:10,
  message:"Time limit is exceed for accessing api",
  standardHeaders:'draft-8',
  legacyHeaders:false
})

app.use(limit);

mongoose.connect(process.env.MONGODB_URL)
.then(()=>{
  console.log("Database is connected")
})
.catch((error)=>{
  console.log("Database is not connected",error)
})


app.use("/api/tasks", taskRoutes);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running.....`);
});
