const rateLimit=(limit,duration)=>{
  return (req,res,next)=>{
    const ip=req.ip;
    const currTime=Date.now();
    const requestMap=new Map();
    const userData=requestMap.get(userIp);
    if(!userData){
        requestMap.set(ip,{
            count:1,
            userTime:currTime
        })
        return next();
    }

    if(currTime-userData.userTime>=duration){
        requestMap.set(ip,{
            count:1,
            userTime:currTime
        })
        return next();
    }

    if(userData.count>limit){
      return res.status(429).json({
        success:false,
        message:"Max limit reached"
      })
    }
    userData.count++;
    return next();
  }
}

module.exports=rateLimit





