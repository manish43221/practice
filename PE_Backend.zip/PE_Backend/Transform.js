//Code to demo transform using pipe
import fs from 'fs'
import zlib from "zlib"
//Create read Stream
const readStream=fs.createReadStream("./test.txt");
// Transform
const gzip=zlib.createGzip()
//Create and write on Stream
const writeStream=fs.createWriteStream("./data.txt");

//DO craete and use pipe

readStream.pipe(gzip)
.pipe(writeStream)
