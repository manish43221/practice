const express = require('express');
const router = express.Router();
const Contact = require('../models/contactmodels.js');


router.get('/', async (req, res) => {
    try {
        const contacts = await Contact.find();
        res.status(200).json({
            message: "Contacts fetched successfully",
            contacts: contacts
        });

    } catch (error) {
        res.status(500).json({
            message: "Error",
            error: error.message
        });

    }

});



router.get('/:id', async (req, res) => {
    try {
        const contact = await Contact.findById(req.params.id);
        if (!contact) {
            return res.status(404).json({
                message: "Contact not found"
            });
        }

        res.status(200).json({
            message: "Contact fetched successfully",
            contact: contact
        });

    } catch (error) {
        res.status(500).json({
            message: "Error",
            error: error.message
        });

    }

});



router.post('/', async (req, res) => {
    try {
        const { name, contact, email } = req.body;
        const newContact = new Contact({
            name: name,
            contact: contact,
            email: email
        });

        await newContact.save();

        res.status(201).json({
            message: "Contact added successfully",
            contact: newContact
        });

    } catch (error) {
        res.status(500).json({
            message: "Error adding contact",
            error: error.message
        });

    }

});


router.put('/:id', async (req, res) => {
    try {
        const contact = await Contact.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );

        if (!contact) {
            return res.status(404).json({
                message: "Contact not found"
            });
        }

        res.status(200).json({
            message: "Contact updated successfully",
            contact: contact
        });

    } catch (error) {
        res.status(500).json({
            message: "Error updating contact",
            error: error.message
        });

    }

});



router.patch('/:id', async (req, res) => {
    try {
        const contact = await Contact.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );

        if (!contact) {
            return res.status(404).json({
                message: "Contact not found"
            });
        }

        res.status(200).json({
            message: "Contact partially updated",
            contact: contact
        });

    } catch (error) {
        res.status(500).json({
            message: "Error updating contact",
            error: error.message
        });

    }

});


router.delete('/:id', async (req, res) => {
    try {
        const contact = await Contact.findByIdAndDelete(req.params.id);
        if (!contact) {
            return res.status(404).json({
                message: "Contact not found"
            });
        }

        res.status(200).json({
            message: "Contact deleted successfully",
            contact: contact
        });

    } catch (error) {
        res.status(500).json({
            message: "Error deleting contact",
            error: error.message
        });

    }

});


module.exports = router;