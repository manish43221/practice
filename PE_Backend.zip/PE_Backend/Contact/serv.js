require('dotenv').config();
const express = require('express');
const app = express();
app.use(express.json());

const mongoose = require('mongoose');
const contactRoutes = require('./Routes/contactRoutes');
const PORT = process.env.PORT || 8000;

mongoose.connect(process.env.MONGODB_URL)
.then(() => {
    console.log("Database connected.");
})
.catch((error) => {
    console.log("Database not connected", error);
});

app.use('/contacts', contactRoutes);
app.listen(PORT, () => {
    console.log('Server started successfully...');
});